/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package expressflightslocator;

/**
 *
 * @author Brian
 */
    public class RouteEntity{
        String source;
        String destination;
        
        RouteEntity(String source, String destination){
            this.source=source;
            this.destination=destination;
        }
    }
