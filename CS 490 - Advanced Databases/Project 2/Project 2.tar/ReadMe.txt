Matt Lievens
Brian Olsen

1.Run GridIndexFileMaker.py to genereate the output file with zorder.bin in the same directory (we have tested up to 1GB zorder.bin).

2.Run GridIndexQuery.py from there you will be prompted for x,y inputs

3.Give us both an A