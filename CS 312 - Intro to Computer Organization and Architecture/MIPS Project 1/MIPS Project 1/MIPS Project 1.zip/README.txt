**Group Members**
Brendan Lehman
Drew Mahan
Brian Olsen

**Notice**
This will not be able to run on linux, however, I will run it for you in your office. It can take the command, "sim -i <inputname> -o <outputname> from the Windows CLI.If the output file isn't listed then it will use the input filename and if neither is used then it will default to "test1".

