#include <iostream>
#include <string>
#include <math.h>
#include "p05.h"
#include "Event.h"
#include "EventTracker.h"
#include "EventCountDown.h"

using namespace std;
namespace P05{

		// Returns a TimeInterval structure containing the time elapsed between
		// the event tracked and the current date.
		int EventCountDown::TimeElapsed(const Event& eventTracked,
			                   const Event& currentDate){

								   int days=0;

								   int Month[] = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365};

								   if (eventTracked.ToString() == currentDate.ToString()){ //case where the same day is entered.

									   return days;

								   }


								   int currentDays=(currentDate.GetYear()-Event().GetYear())*365;//calculates how many years in days there are for both events
								   int eventDays=(eventTracked.GetYear()-Event().GetYear())*365;

								   int year=Event().GetYear();//default year to track the leap year for loop

								   for(year; year <= currentDate.GetYear() && eventTracked.GetYear();year++){ 

									 if(Event::IsLeap(year)){ //leap year for loop will add 1 day, if applicable to either of the day counters

										 if(currentDate.GetYear() >=year){
										 
										 currentDays++;

										 }

										 if(eventTracked.GetYear() >=year){
										 
										 eventDays++;

										 }
									

									 }
								   


								   }


								   currentDays+=Month[currentDate.GetMonth()-1];//adds the amount of days up to the month before current year
								   eventDays+=Month[eventTracked.GetMonth()-1];

								   currentDays+=currentDate.GetDay();//adds the amount of days in the current month
								   eventDays+=eventTracked.GetDay();
								   
								   days=eventDays-currentDays;//assigns the difference of the total to days int

								   return days;




		}

}//end namespace P05