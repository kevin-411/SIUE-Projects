#ifndef P05_H
#define P05_H

namespace P05 {	
	const int MAX_EVENTS_TRACKED = 500;
	typedef unsigned int uint;

	typedef enum {
		kInThePast,
		kInTheFuture
	} TimeOrdering;

}// end namespace P05

#endif