#ifndef P07_H
#define P07_H

#include <iomanip>
using namespace std;

namespace P07 {
	typedef unsigned int uint;

	#define TAB(n) setw(n) << " "

}// end namespace
#endif