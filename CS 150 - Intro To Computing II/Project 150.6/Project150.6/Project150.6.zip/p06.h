#ifndef P06_H
#define P06_H

namespace P06 {
	typedef unsigned int uint;

	// Set up a macro to handle tabbing.
	#define TAB(n) setw(n) << " "
}// end namespace P06

#endif