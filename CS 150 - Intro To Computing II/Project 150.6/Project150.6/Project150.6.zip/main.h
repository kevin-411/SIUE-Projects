#include <iostream>
#include <string>
#include <iomanip>

#include "AccountRecord.h"
#include "AccountsReceivable.h"
#include "p06.h"

using namespace std;
using namespace P06;

void TestAccountRecordClass();
void TestAccountsReceivableClass();