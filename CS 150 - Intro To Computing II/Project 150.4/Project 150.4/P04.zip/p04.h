#ifndef P04_H
#define P04_H

namespace P04 {
	typedef unsigned int uint;
	
	typedef enum {
		ASCENDING,
		DESCENDING
	} SortOrder;

}// end namespace
#endif